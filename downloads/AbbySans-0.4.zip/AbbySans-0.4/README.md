# Abby Sans 0.4

Hangry's typeface for apps, websites, internal tools, social posts, campaigns
and packaging. Nine weights from Thin 100 to Black 900, each with a true italic.
Latin (including Vietnamese) and Cyrillic, 362 languages.

## What's inside
- `variable/` – variable fonts, upright and italic (TTF for desktop and Figma,
  WOFF2 for the web). One file covers every weight.
- `static/desktop/` – one hinted TTF per weight and style, for Office, print
  and older apps.
- `static/web/` – one WOFF2 per weight and style, if you can't use the
  variable font.

## Install
- **Mac:** double-click the TTFs in `variable/` (or `static/desktop/`) and
  click Install Font. Restart Figma afterwards.
- **Windows:** right-click the TTFs and choose Install for all users.
- **Web:**

```css
@font-face {
  font-family: "Abby Sans";
  src: url("AbbySans[wght].woff2") format("woff2");
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: "Abby Sans";
  src: url("AbbySans-Italic[wght].woff2") format("woff2");
  font-weight: 100 900;
  font-style: italic;
  font-display: swap;
}
```

## How to use it
- **Software:** Regular 400 for body text at 14 to 16px, Medium 500 for labels
  and buttons, SemiBold 600 or Bold 700 for titles.
- **Marketing:** Black 900 or ExtraBold 800 for headlines, with letter spacing
  around −3% to −5%.

## License
Abby Sans is based on Geist by Vercel and is licensed under the SIL Open Font
License 1.1 (see `OFL.txt`). You can use, embed and ship it in anything, for
free. Don't sell the font files on their own, and keep `OFL.txt` with them.
